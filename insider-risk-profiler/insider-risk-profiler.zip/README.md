What is this and how do I run it?
=====

This directory is a stand-alone nodejs app. It has no references outside of this folder. The code in this folder represent the insider 
risk profiler application under the Eaton umbrella.

Run this by issuing the command "node app.js"
